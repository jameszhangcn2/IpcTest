"""CAN 日志分析 pytest 测试用例。

运行方式：
    # 分析单个日志文件
    pytest tests/test_can_analysis.py --can-log=path/to/log.asc -v

    # 批量分析目录下所有日志
    pytest tests/test_can_analysis.py --can-log-dir=path/to/logs/ --output=output/ -v

    # 指定波特率和最少帧数校验
    pytest tests/test_can_analysis.py --can-log=log.asc --baudrate=250000 --min-frames=100 -v

    # 使用示例日志（默认）
    pytest tests/test_can_analysis.py -v
"""

from __future__ import annotations

import os

import pytest

from can_analyzer.parser import parse_log_file, CanFrame
from can_analyzer.analyzer import CanLogAnalyzer
from can_analyzer.exporter import export_to_excel


# ---------------------------------------------------------------------------
# 参数化：对每个日志文件执行完整分析流程
# ---------------------------------------------------------------------------

def pytest_generate_tests(metafunc):
    """动态参数化：为每个日志文件生成一个测试用例。"""
    if "log_file" in metafunc.fixturenames:
        log_file = metafunc.config.getoption("--can-log")
        log_dir = metafunc.config.getoption("--can-log-dir")

        files = []
        if log_file:
            files.append(os.path.abspath(log_file))
        if log_dir:
            import glob
            for ext in ("*.asc", "*.log"):
                files.extend(glob.glob(os.path.join(log_dir, ext)))
                files.extend(glob.glob(os.path.join(log_dir, "**", ext), recursive=True))

        files = sorted(set(files))

        if not files:
            # 默认示例日志
            sample = os.path.join(
                os.path.dirname(__file__), "..", "sample_logs", "sample.asc"
            )
            sample = os.path.abspath(sample)
            if os.path.exists(sample):
                files.append(sample)

        if not files:
            pytest.skip("未指定日志文件，且未找到示例日志")

        metafunc.parametrize(
            "log_file",
            files,
            ids=[os.path.basename(f) for f in files],
        )


# ---------------------------------------------------------------------------
# 测试用例
# ---------------------------------------------------------------------------

class TestCanLogAnalysis:
    """CAN 日志分析完整流程测试。"""

    def test_parse_log_file(self, log_file, min_frames):
        """测试日志文件解析。"""
        frames = parse_log_file(log_file)

        assert isinstance(frames, list), "解析结果应为列表"
        assert len(frames) >= min_frames, (
            f"日志帧数 {len(frames)} 少于阈值 {min_frames}"
        )

        # 验证每帧结构
        for frame in frames[:100]:  # 只检查前 100 帧
            assert isinstance(frame, CanFrame)
            assert frame.timestamp >= 0, "时间戳应为非负数"
            assert frame.channel >= 0, "通道号应为非负数"
            assert 0 <= frame.dlc <= 8, f"DLC 应在 0-8 之间，实际: {frame.dlc}"
            if not frame.is_remote and not frame.is_error:
                assert len(frame.data) == frame.dlc, (
                    f"数据长度 {len(frame.data)} 与 DLC {frame.dlc} 不匹配"
                )

        # 验证时间戳递增
        timestamps = [f.timestamp for f in frames]
        assert timestamps == sorted(timestamps), "时间戳应按升序排列"

    def test_analyze_frames(self, log_file, baudrate, dbc):
        """测试帧数据分析。"""
        frames = parse_log_file(log_file)
        analyzer = CanLogAnalyzer(baudrate=baudrate)
        result = analyzer.analyze(frames, file_path=log_file, dbc=dbc)

        assert result.total_frames == len(frames), "总帧数应与解析帧数一致"
        assert result.unique_ids > 0, "应至少有一个唯一 CAN ID"
        assert len(result.channels) > 0, "应至少有一个通道"

        # 验证报文统计
        total_msg_frames = sum(
            m.frame_count for m in result.messages.values() if m.can_id >= 0
        )
        error_count = result.total_error_frames
        assert total_msg_frames + error_count == len(frames), (
            f"报文统计帧数({total_msg_frames}) + 错误帧({error_count}) "
            f"应等于总帧数({len(frames)})"
        )

        # 验证通道统计
        for ch, stats in result.channels.items():
            assert stats.total_frames > 0, f"通道 {ch} 应有帧"
            assert stats.duration >= 0, "持续时间应为非负"
            assert 0 <= stats.bus_load_percent <= 100, "总线负载应在 0-100% 之间"

    def test_export_to_excel(self, log_file, output_dir, baudrate, dbc, tmp_path):
        """测试 Excel 导出。"""
        frames = parse_log_file(log_file)
        analyzer = CanLogAnalyzer(baudrate=baudrate)
        result = analyzer.analyze(frames, file_path=log_file, dbc=dbc)

        # 确定输出路径
        base_name = os.path.splitext(os.path.basename(log_file))[0]
        if os.path.isdir(output_dir) or not os.path.splitext(output_dir)[1]:
            os.makedirs(output_dir, exist_ok=True)
            excel_path = os.path.join(output_dir, f"{base_name}_analysis.xlsx")
        else:
            excel_path = output_dir

        # 导出
        saved_path = export_to_excel(result, excel_path)

        # 验证文件存在且非空
        assert os.path.exists(saved_path), f"Excel 文件应存在: {saved_path}"
        assert os.path.getsize(saved_path) > 0, "Excel 文件不应为空"

        # 验证 Excel 内容
        import openpyxl
        wb = openpyxl.load_workbook(saved_path)
        expected_sheets = {"概览", "报文统计", "通道统计", "错误帧", "原始数据摘要"}
        actual_sheets = set(wb.sheetnames)
        assert expected_sheets.issubset(actual_sheets), (
            f"Excel 应包含所有预期 Sheet。预期: {expected_sheets}, 实际: {actual_sheets}"
        )

        # 验证报文统计 Sheet 有数据
        ws = wb["报文统计"]
        assert ws.max_row >= 2, "报文统计 Sheet 应有表头和至少一行数据"

        wb.close()

    def test_period_analysis(self, log_file, baudrate, dbc):
        """测试周期分析的合理性。"""
        frames = parse_log_file(log_file)
        analyzer = CanLogAnalyzer(baudrate=baudrate)
        result = analyzer.analyze(frames, file_path=log_file, dbc=dbc)

        for key, stats in result.messages.items():
            if stats.can_id < 0 or stats.frame_count < 2:
                continue

            # 周期应为正数
            if stats.periods:
                assert all(p > 0 for p in stats.periods), "所有周期应为正数"
                assert stats.min_period <= stats.avg_period <= stats.max_period, (
                    f"周期关系应满足 min <= avg <= max，"
                    f"实际: min={stats.min_period}, avg={stats.avg_period}, max={stats.max_period}"
                )

            # 频率应为正数
            if stats.avg_frequency:
                assert stats.avg_frequency > 0, "平均频率应为正数"

    def test_no_corrupted_frames(self, log_file):
        """测试解析结果中没有损坏的帧。"""
        frames = parse_log_file(log_file)

        for i, frame in enumerate(frames):
            # CAN ID 范围检查
            if frame.is_extended:
                assert frame.can_id <= 0x1FFFFFFF, f"扩展帧 ID 超出范围: {frame.can_id_hex}"
            else:
                assert frame.can_id <= 0x7FF, f"标准帧 ID 超出范围: {frame.can_id_hex}"

            # 数据字节范围检查
            for byte in frame.data:
                assert 0 <= byte <= 255, f"数据字节应在 0-255 之间: {byte}"


# ---------------------------------------------------------------------------
# 单元测试：解析器
# ---------------------------------------------------------------------------

class TestParserUnit:
    """解析器单元测试。"""

    def test_can_frame_properties(self):
        frame = CanFrame(
            timestamp=1.234,
            channel=1,
            can_id=0x100,
            is_extended=False,
            is_remote=False,
            is_error=False,
            direction="Rx",
            dlc=8,
            data=[0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88],
        )
        assert frame.can_id_hex == "0x100"
        assert frame.data_hex == "11 22 33 44 55 66 77 88"

    def test_extended_frame_id(self):
        frame = CanFrame(
            timestamp=0.0,
            channel=0,
            can_id=0x18FEF100,
            is_extended=True,
            is_remote=False,
            is_error=False,
            direction="Rx",
            dlc=8,
            data=[],
        )
        assert frame.can_id_hex == "0x18FEF100"

    def test_parse_asc_standard_frame(self, tmp_path):
        """测试解析标准 .asc 帧。"""
        asc_content = """date Mon Jan 01 00:00:00 2024
base hex  timestamps absolute
no internal events logged
// version 9.0
   0.000123 1  100x        Rx   d 8  11 22 33 44 55 66 77 88
   0.010000 1  200x        Rx   d 4  AA BB CC DD
   0.020000 1  100x        Rx   d 8  11 22 33 44 55 66 77 88
"""
        asc_file = tmp_path / "test.asc"
        asc_file.write_text(asc_content)

        frames = parse_log_file(str(asc_file))
        assert len(frames) == 3
        assert frames[0].can_id == 0x100
        assert frames[0].dlc == 8
        assert frames[0].data == [0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88]
        assert frames[1].can_id == 0x200
        assert frames[1].dlc == 4
        assert frames[2].can_id == 0x100

    def test_parse_asc_remote_frame(self, tmp_path):
        """测试解析远程帧。"""
        asc_content = """base hex  timestamps absolute
   0.001000 1  300x        Rx   r 0
"""
        asc_file = tmp_path / "remote.asc"
        asc_file.write_text(asc_content)

        frames = parse_log_file(str(asc_file))
        assert len(frames) == 1
        assert frames[0].is_remote is True
        assert frames[0].dlc == 0
        assert frames[0].data == []

    def test_parse_asc_error_frame(self, tmp_path):
        """测试解析错误帧。"""
        asc_content = """base hex  timestamps absolute
   0.001000 1  ErrorFrame  ch=1  err=0x00000002
"""
        asc_file = tmp_path / "error.asc"
        asc_file.write_text(asc_content)

        frames = parse_log_file(str(asc_file))
        assert len(frames) == 1
        assert frames[0].is_error is True

    def test_parse_asc_timestamps_sorted(self, tmp_path):
        """测试解析后时间戳排序。"""
        asc_content = """base hex  timestamps absolute
   0.030000 1  100x        Rx   d 8  00 00 00 00 00 00 00 00
   0.010000 1  200x        Rx   d 8  00 00 00 00 00 00 00 00
   0.020000 1  100x        Rx   d 8  00 00 00 00 00 00 00 00
"""
        asc_file = tmp_path / "unsorted.asc"
        asc_file.write_text(asc_content)

        frames = parse_log_file(str(asc_file))
        timestamps = [f.timestamp for f in frames]
        assert timestamps == sorted(timestamps)


# ---------------------------------------------------------------------------
# 单元测试：分析器
# ---------------------------------------------------------------------------

class TestAnalyzerUnit:
    """分析器单元测试。"""

    def _make_frames(self):
        """构造测试帧。"""
        frames = []
        # ID 0x100, 周期 10ms
        for i in range(10):
            frames.append(CanFrame(
                timestamp=i * 0.01,
                channel=1,
                can_id=0x100,
                is_extended=False,
                is_remote=False,
                is_error=False,
                direction="Rx",
                dlc=8,
                data=[i, 0, 0, 0, 0, 0, 0, 0],
            ))
        # ID 0x200, 周期 20ms
        for i in range(5):
            frames.append(CanFrame(
                timestamp=i * 0.02 + 0.005,
                channel=1,
                can_id=0x200,
                is_extended=False,
                is_remote=False,
                is_error=False,
                direction="Tx",
                dlc=4,
                data=[0xAA, 0xBB, 0xCC, 0xDD],
            ))
        frames.sort(key=lambda f: f.timestamp)
        return frames

    def test_basic_analysis(self):
        frames = self._make_frames()
        analyzer = CanLogAnalyzer()
        result = analyzer.analyze(frames, file_path="test.asc")

        assert result.total_frames == 15
        assert result.unique_ids == 2
        assert 1 in result.channels

    def test_period_calculation(self):
        frames = self._make_frames()
        analyzer = CanLogAnalyzer()
        result = analyzer.analyze(frames)

        key_100 = (1, 0x100, "Rx")
        stats_100 = result.messages[key_100]
        assert stats_100.frame_count == 10
        assert abs(stats_100.avg_period - 0.01) < 0.001, (
            f"0x100 平均周期应为 ~10ms，实际: {stats_100.avg_period}"
        )
        assert abs(stats_100.avg_frequency - 100) < 1, (
            f"0x100 平均频率应为 ~100Hz，实际: {stats_100.avg_frequency}"
        )

    def test_data_change_detection(self):
        frames = self._make_frames()
        analyzer = CanLogAnalyzer()
        result = analyzer.analyze(frames)

        key_100 = (1, 0x100, "Rx")
        stats_100 = result.messages[key_100]
        # 0x100 每帧数据第一个字节都在变化
        assert stats_100.data_change_count > 0

        key_200 = (1, 0x200, "Tx")
        stats_200 = result.messages[key_200]
        # 0x200 数据不变
        assert stats_200.data_change_count == 0

    def test_empty_frames(self):
        analyzer = CanLogAnalyzer()
        result = analyzer.analyze([], file_path="empty.asc")
        assert result.total_frames == 0
        assert result.unique_ids == 0
        assert result.duration == 0.0


# ---------------------------------------------------------------------------
# 单元测试：DBC 解析
# ---------------------------------------------------------------------------

class TestDbcParser:
    """DBC 解析器单元测试。"""

    def test_parse_standard_messages(self, tmp_path):
        """测试解析标准帧消息定义。"""
        from can_analyzer.parser import parse_dbc

        dbc_content = """VERSION ""
BS_:
BU_: ECU1

BO_ 256 EngineData: 8 ECU1
 SG_ EngineSpeed : 0|16@0+ (1,0) [0|65535] "rpm" ECU2

BO_ 512 VehicleSpeed: 4 ECU1
 SG_ Speed : 0|16@0+ (0.01,0) [0|655.35] "km/h" ECU2
"""
        dbc_file = tmp_path / "test.dbc"
        dbc_file.write_text(dbc_content)

        dbc = parse_dbc(str(dbc_file))
        assert len(dbc) == 2
        assert 256 in dbc
        assert dbc[256].name == "EngineData"
        assert dbc[256].dlc == 8
        assert dbc[256].sender == "ECU1"
        assert not dbc[256].is_extended
        assert "EngineSpeed" in dbc[256].signals

        assert 512 in dbc
        assert dbc[512].name == "VehicleSpeed"
        assert dbc[512].dlc == 4

    def test_parse_extended_frame(self, tmp_path):
        """测试解析扩展帧消息（ID 带 0x80000000 标志位）。"""
        from can_analyzer.parser import parse_dbc

        # 扩展帧 ID = 真实ID | 0x80000000
        ext_id = 0x18FEF100 | 0x80000000
        dbc_content = f"""VERSION ""
BS_:
BU_: ECU1

BO_ {ext_id} PDU_Transport: 8 ECU1
 SG_ Data : 0|64@0+ (1,0) [0|0] "" ECU2
"""
        dbc_file = tmp_path / "ext.dbc"
        dbc_file.write_text(dbc_content)

        dbc = parse_dbc(str(dbc_file))
        assert len(dbc) == 1
        assert 0x18FEF100 in dbc
        assert dbc[0x18FEF100].name == "PDU_Transport"
        assert dbc[0x18FEF100].is_extended is True

    def test_lookup_message_name(self):
        """测试消息名称查找函数。"""
        from can_analyzer.parser import lookup_message_name, DbcMessage

        dbc = {
            0x100: DbcMessage(can_id=0x100, is_extended=False, name="EngineData", dlc=8, sender="ECU1"),
            0x200: DbcMessage(can_id=0x200, is_extended=False, name="VehicleSpeed", dlc=4, sender="ECU1"),
        }

        assert lookup_message_name(dbc, 0x100) == "EngineData"
        assert lookup_message_name(dbc, 0x200) == "VehicleSpeed"
        assert lookup_message_name(dbc, 0x300) == ""  # 未找到
        assert lookup_message_name(None, 0x100) == ""  # dbc 为 None

    def test_analyze_with_dbc(self):
        """测试使用 DBC 进行分析，消息名称应被正确填充。"""
        from can_analyzer.parser import parse_dbc, DbcMessage
        from can_analyzer.analyzer import CanLogAnalyzer

        # 构造帧
        frames = []
        for i in range(5):
            frames.append(CanFrame(
                timestamp=i * 0.01,
                channel=1,
                can_id=0x100,
                is_extended=False,
                is_remote=False,
                is_error=False,
                direction="Rx",
                dlc=8,
                data=[0] * 8,
            ))
        frames.append(CanFrame(
            timestamp=0.05,
            channel=1,
            can_id=0x999,  # DBC 中未定义
            is_extended=False,
            is_remote=False,
            is_error=False,
            direction="Rx",
            dlc=8,
            data=[0] * 8,
        ))

        dbc = {
            0x100: DbcMessage(can_id=0x100, is_extended=False, name="EngineData", dlc=8, sender="ECU1"),
        }

        analyzer = CanLogAnalyzer()
        result = analyzer.analyze(frames, file_path="test.asc", dbc=dbc)

        key_100 = (1, 0x100, "Rx")
        assert result.messages[key_100].message_name == "EngineData"

        key_999 = (1, 0x999, "Rx")
        assert result.messages[key_999].message_name == ""  # 未定义的 ID 名称为空

    def test_signal_properties(self, tmp_path):
        """测试信号属性解析。"""
        from can_analyzer.parser import parse_dbc

        dbc_content = """VERSION ""
BS_:
BU_: ECU1

BO_ 256 Msg: 8 ECU1
 SG_ Speed : 0|16@0+ (0.5,10) [0|100] "km/h" ECU2
 SG_ Temp : 16|8@1- (0.1,-40) [-40|215] "degC" ECU2
"""
        dbc_file = tmp_path / "sig.dbc"
        dbc_file.write_text(dbc_content)

        dbc = parse_dbc(str(dbc_file))
        msg = dbc[256]

        speed = msg.signals["Speed"]
        assert speed.start_bit == 0
        assert speed.length == 16
        assert speed.is_little_endian is False  # @0 = big endian
        assert speed.is_signed is False  # + = unsigned
        assert speed.factor == 0.5
        assert speed.offset == 10
        assert speed.unit == "km/h"

        temp = msg.signals["Temp"]
        assert temp.start_bit == 16
        assert temp.length == 8
        assert temp.is_little_endian is True  # @1 = little endian
        assert temp.is_signed is True  # - = signed
        assert temp.unit == "degC"

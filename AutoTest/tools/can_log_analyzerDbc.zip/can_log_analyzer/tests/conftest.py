"""pytest 配置与 fixtures。

支持通过命令行参数指定 CAN 日志文件路径和 DBC 数据库：
    pytest --can-log=path/to/log.asc --dbc=path/to/db.dbc --output=path/to/report.xlsx

也支持批量分析目录下所有 .asc 文件：
    pytest --can-log-dir=path/to/logs/ --dbc=path/to/db.dbc --output=output/
"""

from __future__ import annotations

import os
import glob
from typing import List, Optional, Dict, Any

import pytest

from can_analyzer.parser import parse_log_file, parse_dbc
from can_analyzer.analyzer import CanLogAnalyzer
from can_analyzer.exporter import export_to_excel


def pytest_addoption(parser):
    """添加命令行选项。"""
    parser.addoption(
        "--can-log",
        action="store",
        default=None,
        help="单个 CAN 日志文件路径 (.asc / .log)",
    )
    parser.addoption(
        "--can-log-dir",
        action="store",
        default=None,
        help="CAN 日志文件目录，将分析目录下所有 .asc / .log 文件",
    )
    parser.addoption(
        "--dbc",
        action="store",
        default=None,
        help="DBC 数据库文件路径，用于匹配消息名称和信号定义",
    )
    parser.addoption(
        "--output",
        action="store",
        default="output",
        help="Excel 输出目录或文件路径（默认: output/）",
    )
    parser.addoption(
        "--baudrate",
        action="store",
        type=int,
        default=500000,
        help="CAN 总线波特率，用于估算总线负载（默认: 500000）",
    )
    parser.addoption(
        "--min-frames",
        action="store",
        type=int,
        default=1,
        help="日志最少帧数校验阈值（默认: 1）",
    )


def _collect_log_files(config) -> List[str]:
    """收集需要分析的日志文件列表。"""
    log_file = config.getoption("--can-log")
    log_dir = config.getoption("--can-log-dir")

    files: List[str] = []

    if log_file:
        if not os.path.exists(log_file):
            pytest.fail(f"日志文件不存在: {log_file}")
        files.append(os.path.abspath(log_file))

    if log_dir:
        if not os.path.isdir(log_dir):
            pytest.fail(f"日志目录不存在: {log_dir}")
        for ext in ("*.asc", "*.log"):
            files.extend(glob.glob(os.path.join(log_dir, ext)))
            files.extend(glob.glob(os.path.join(log_dir, "**", ext), recursive=True))

    # 去重
    files = sorted(set(files))

    if not files:
        # 默认使用示例日志
        sample = os.path.join(os.path.dirname(__file__), "..", "sample_logs", "sample.asc")
        sample = os.path.abspath(sample)
        if os.path.exists(sample):
            files.append(sample)

    return files


def _load_dbc(config) -> Optional[Dict[int, Any]]:
    """加载 DBC 文件，返回消息字典。"""
    dbc_path = config.getoption("--dbc")
    if not dbc_path:
        return None
    if not os.path.exists(dbc_path):
        pytest.fail(f"DBC 文件不存在: {dbc_path}")
    dbc = parse_dbc(dbc_path)
    print(f"[DBC] 已加载 {len(dbc)} 条消息定义: {dbc_path}")
    return dbc


def _resolve_output_path(log_file: str, output_option: str) -> str:
    """根据日志文件名和输出选项，确定 Excel 输出路径。"""
    base_name = os.path.splitext(os.path.basename(log_file))[0]

    if os.path.isdir(output_option) or not os.path.splitext(output_option)[1]:
        # 输出是目录
        os.makedirs(output_option, exist_ok=True)
        return os.path.join(output_option, f"{base_name}_analysis.xlsx")
    else:
        # 输出是具体文件
        return output_option


@pytest.fixture(scope="session")
def log_files(request) -> List[str]:
    """返回需要分析的日志文件列表。"""
    return _collect_log_files(request.config)


@pytest.fixture(scope="session")
def dbc(request) -> Optional[Dict[int, Any]]:
    """返回解析后的 DBC 消息字典，未指定时返回 None。"""
    return _load_dbc(request.config)


@pytest.fixture(scope="session")
def baudrate(request) -> int:
    """返回 CAN 总线波特率。"""
    return request.config.getoption("--baudrate")


@pytest.fixture(scope="session")
def output_dir(request) -> str:
    """返回输出目录/路径。"""
    return request.config.getoption("--output")


@pytest.fixture(scope="session")
def min_frames(request) -> int:
    """返回最少帧数校验阈值。"""
    return request.config.getoption("--min-frames")


@pytest.fixture
def analyze_log():
    """提供一个分析单个日志文件的函数。

    返回 (frames, result, excel_path) 三元组。
    """
    def _analyze(log_file: str, output_path: str, baudrate: int = 500000,
                 dbc: Optional[Dict[int, Any]] = None):
        frames = parse_log_file(log_file)
        analyzer = CanLogAnalyzer(baudrate=baudrate)
        result = analyzer.analyze(frames, file_path=log_file, dbc=dbc)
        excel_path = export_to_excel(result, output_path)
        return frames, result, excel_path

    return _analyze

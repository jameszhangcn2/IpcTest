"""CAN 日志分析器。

对解析后的 CanFrame 列表进行多维度统计分析：
- 报文级统计（每 ID 的帧数、周期、占空比等）
- 总线负载估算
- 错误帧统计
- 通道统计
- 信号变化统计（基于数据字节）
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from statistics import mean, stdev
from typing import Dict, List, Optional, Any

from .parser import CanFrame, lookup_message_name


@dataclass
class MessageStats:
    """单个 CAN ID 的统计信息。"""

    can_id: int
    is_extended: bool
    channel: int
    direction: str
    message_name: str = ""       # DBC 消息名称
    frame_count: int = 0
    first_time: float = 0.0
    last_time: float = 0.0
    dlc: int = 0
    periods: List[float] = field(default_factory=list)
    data_samples: List[List[int]] = field(default_factory=list)

    @property
    def duration(self) -> float:
        """报文出现的时间跨度（秒）。"""
        return self.last_time - self.first_time

    @property
    def avg_period(self) -> Optional[float]:
        """平均周期（秒）。"""
        return mean(self.periods) if self.periods else None

    @property
    def min_period(self) -> Optional[float]:
        return min(self.periods) if self.periods else None

    @property
    def max_period(self) -> Optional[float]:
        return max(self.periods) if self.periods else None

    @property
    def period_jitter(self) -> Optional[float]:
        """周期抖动（标准差，秒）。"""
        return stdev(self.periods) if len(self.periods) > 1 else None

    @property
    def avg_frequency(self) -> Optional[float]:
        """平均频率（Hz）。"""
        if self.avg_period and self.avg_period > 0:
            return 1.0 / self.avg_period
        return None

    @property
    def data_change_count(self) -> int:
        """数据字节发生变化的次数。"""
        if len(self.data_samples) < 2:
            return 0
        changes = 0
        for i in range(1, len(self.data_samples)):
            if self.data_samples[i] != self.data_samples[i - 1]:
                changes += 1
        return changes


@dataclass
class ChannelStats:
    """单个 CAN 通道的统计信息。"""

    channel: int
    total_frames: int = 0
    unique_ids: int = 0
    error_frames: int = 0
    tx_frames: int = 0
    rx_frames: int = 0
    first_time: float = 0.0
    last_time: float = 0.0
    bus_load_percent: float = 0.0  # 估算总线负载（假设 500kbps）

    @property
    def duration(self) -> float:
        return self.last_time - self.first_time

    @property
    def avg_frames_per_sec(self) -> float:
        if self.duration > 0:
            return self.total_frames / self.duration
        return 0.0


@dataclass
class AnalysisResult:
    """完整的分析结果。"""

    file_path: str
    total_frames: int
    duration: float
    channels: Dict[int, ChannelStats] = field(default_factory=dict)
    messages: Dict[tuple, MessageStats] = field(default_factory=dict)  # key: (channel, can_id, direction)
    error_frames: List[CanFrame] = field(default_factory=list)

    @property
    def unique_ids(self) -> int:
        return len(self.messages)

    @property
    def total_error_frames(self) -> int:
        return len(self.error_frames)


class CanLogAnalyzer:
    """CAN 日志分析器。"""

    def __init__(self, baudrate: int = 500000):
        """
        Args:
            baudrate: CAN 总线波特率，用于估算总线负载，默认 500kbps。
        """
        self.baudrate = baudrate

    def analyze(self, frames: List[CanFrame], file_path: str = "",
                dbc: Optional[Dict[int, Any]] = None) -> AnalysisResult:
        """对 CAN 帧列表执行完整分析。

        Args:
            frames: 解析后的 CanFrame 列表。
            file_path: 源文件路径，用于记录。
            dbc: parse_dbc 返回的 DBC 消息字典，用于匹配消息名称。

        Returns:
            AnalysisResult 分析结果。
        """
        result = AnalysisResult(
            file_path=file_path,
            total_frames=len(frames),
            duration=0.0,
        )

        if not frames:
            return result

        result.duration = frames[-1].timestamp - frames[0].timestamp

        # 按 (channel, can_id, direction) 分组
        msg_groups: Dict[tuple, List[CanFrame]] = defaultdict(list)
        for frame in frames:
            if frame.is_error:
                result.error_frames.append(frame)
                key = (frame.channel, -1, frame.direction)  # 错误帧用特殊 ID
            else:
                key = (frame.channel, frame.can_id, frame.direction)
            msg_groups[key].append(frame)

        for key, group in msg_groups.items():
            channel, can_id, direction = key
            first = group[0]
            stats = MessageStats(
                can_id=can_id,
                is_extended=first.is_extended,
                channel=channel,
                direction=direction,
                message_name=lookup_message_name(dbc, can_id) if can_id >= 0 else "",
                frame_count=len(group),
                first_time=first.timestamp,
                last_time=group[-1].timestamp,
                dlc=first.dlc,
            )

            # 计算周期
            for i in range(1, len(group)):
                stats.periods.append(group[i].timestamp - group[i - 1].timestamp)

            # 采样数据（最多保留 100 个样本用于变化检测）
            step = max(1, len(group) // 100)
            stats.data_samples = [f.data for f in group[::step]]

            result.messages[key] = stats

        # 通道统计
        channel_groups: Dict[int, List[CanFrame]] = defaultdict(list)
        for frame in frames:
            channel_groups[frame.channel].append(frame)

        for channel, ch_frames in channel_groups.items():
            ch_stats = ChannelStats(
                channel=channel,
                total_frames=len(ch_frames),
                unique_ids=len(set(f.can_id for f in ch_frames if not f.is_error)),
                error_frames=sum(1 for f in ch_frames if f.is_error),
                tx_frames=sum(1 for f in ch_frames if f.direction == "Tx"),
                rx_frames=sum(1 for f in ch_frames if f.direction == "Rx"),
                first_time=ch_frames[0].timestamp,
                last_time=ch_frames[-1].timestamp,
            )

            # 估算总线负载：标准帧约 130 位（含填充），扩展帧约 150 位
            total_bits = 0
            for f in ch_frames:
                if f.is_error:
                    total_bits += 24  # 错误帧约 24 位
                elif f.is_extended:
                    total_bits += 150 + f.dlc * 8
                else:
                    total_bits += 130 + f.dlc * 8

            if ch_stats.duration > 0:
                ch_stats.bus_load_percent = min(
                    100.0,
                    (total_bits / ch_stats.duration) / self.baudrate * 100,
                )

            result.channels[channel] = ch_stats

        return result

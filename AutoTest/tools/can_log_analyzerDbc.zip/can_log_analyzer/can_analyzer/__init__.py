"""CAN 日志分析工具包。

支持 Vector .asc 格式日志解析、统计分析与 Excel 汇总导出。
支持 DBC 数据库解析，自动匹配消息名称。
"""

from .parser import (
    CanFrame,
    parse_asc,
    parse_log_file,
    parse_dbc,
    DbcMessage,
    DbcSignal,
    lookup_message_name,
)
from .analyzer import CanLogAnalyzer, AnalysisResult
from .exporter import export_to_excel

__all__ = [
    "CanFrame",
    "parse_asc",
    "parse_log_file",
    "parse_dbc",
    "DbcMessage",
    "DbcSignal",
    "lookup_message_name",
    "CanLogAnalyzer",
    "AnalysisResult",
    "export_to_excel",
]

#!/usr/bin/env python3
"""CAN 日志分析命令行工具。

直接运行（无需 pytest）：
    python run_analysis.py path/to/log.asc
    python run_analysis.py path/to/log.asc -o output/report.xlsx
    python run_analysis.py path/to/log.asc -b 250000
    python run_analysis.py --dir path/to/logs/ -o output/
"""

from __future__ import annotations

import argparse
import glob
import os
import sys

from can_analyzer import parse_log_file, CanLogAnalyzer, export_to_excel


def analyze_single(log_path: str, output: str, baudrate: int) -> str:
    """分析单个日志文件。"""
    print(f"[解析] {log_path}")
    frames = parse_log_file(log_path)
    print(f"  -> 共解析 {len(frames)} 帧")

    analyzer = CanLogAnalyzer(baudrate=baudrate)
    result = analyzer.analyze(frames, file_path=log_path)

    print(f"[分析] 唯一ID: {result.unique_ids}, 通道: {len(result.channels)}, "
          f"错误帧: {result.total_error_frames}, 时长: {result.duration:.3f}s")

    # 确定输出路径
    if os.path.isdir(output) or not os.path.splitext(output)[1]:
        os.makedirs(output, exist_ok=True)
        base = os.path.splitext(os.path.basename(log_path))[0]
        excel_path = os.path.join(output, f"{base}_analysis.xlsx")
    else:
        excel_path = output

    saved = export_to_excel(result, excel_path)
    print(f"[导出] {saved}")
    print()
    return saved


def main():
    parser = argparse.ArgumentParser(
        description="CAN 日志分析工具 - 解析 CAN 日志并汇总到 Excel",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  %(prog)s log.asc                    分析单个文件
  %(prog)s log.asc -o report.xlsx     指定输出文件
  %(prog)s log.asc -b 250000          指定波特率 250kbps
  %(prog)s --dir logs/ -o output/     批量分析目录
        """,
    )
    parser.add_argument("log_file", nargs="?", help="CAN 日志文件路径 (.asc / .log)")
    parser.add_argument("--dir", "-d", help="批量分析目录下所有 .asc / .log 文件")
    parser.add_argument("--output", "-o", default="output", help="输出目录或文件路径 (默认: output)")
    parser.add_argument("--baudrate", "-b", type=int, default=500000, help="CAN 波特率 bps (默认: 500000)")

    args = parser.parse_args()

    if not args.log_file and not args.dir:
        parser.print_help()
        sys.exit(1)

    files = []
    if args.log_file:
        if not os.path.exists(args.log_file):
            print(f"错误: 文件不存在 {args.log_file}", file=sys.stderr)
            sys.exit(1)
        files.append(args.log_file)

    if args.dir:
        if not os.path.isdir(args.dir):
            print(f"错误: 目录不存在 {args.dir}", file=sys.stderr)
            sys.exit(1)
        for ext in ("*.asc", "*.log"):
            files.extend(glob.glob(os.path.join(args.dir, ext)))
            files.extend(glob.glob(os.path.join(args.dir, "**", ext), recursive=True))
        files = sorted(set(files))

    if not files:
        print("未找到任何日志文件", file=sys.stderr)
        sys.exit(1)

    print(f"=== CAN 日志分析 ({len(files)} 个文件) ===")
    print()

    results = []
    for f in files:
        try:
            saved = analyze_single(f, args.output, args.baudrate)
            results.append((f, saved, None))
        except Exception as e:
            print(f"[错误] 分析 {f} 失败: {e}")
            results.append((f, None, str(e)))

    print("=== 完成 ===")
    success = sum(1 for _, _, err in results if err is None)
    failed = len(results) - success
    print(f"成功: {success}, 失败: {failed}")

    if failed > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()

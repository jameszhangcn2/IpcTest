"""CAN 日志解析器。

支持 Vector .asc (CANoe) 文本格式，以及 Peak .log / candump 简单格式。
纯 Python 实现，无外部依赖。
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class CanFrame:
    """一帧 CAN 报文。"""

    timestamp: float          # 时间戳（秒）
    channel: int              # 通道号
    can_id: int               # CAN ID（十进制）
    is_extended: bool         # 是否扩展帧
    is_remote: bool           # 是否远程帧
    is_error: bool            # 是否错误帧
    direction: str            # "Rx" / "Tx"
    dlc: int                  # 数据长度
    data: List[int] = field(default_factory=list)  # 数据字节

    @property
    def can_id_hex(self) -> str:
        """十六进制 ID 字符串。"""
        return f"0x{self.can_id:03X}" if not self.is_extended else f"0x{self.can_id:08X}"

    @property
    def data_hex(self) -> str:
        """数据字节十六进制字符串。"""
        return " ".join(f"{b:02X}" for b in self.data)


# ---------------------------------------------------------------------------
# .asc 解析
# ---------------------------------------------------------------------------

# 典型 .asc 帧行：
#   0.000123 1  100x        Rx   d 8  11 22 33 44 55 66 77 88
#   1.234567 1  100x        Rx   r 0
# 扩展帧 ID 带 'x' 后缀，标准帧也可能带 'x'。
# 错误帧：ErrorFrame 或 带 'Error' 标记。

_ASC_FRAME_RE = re.compile(
    r"^\s*"
    r"(?P<ts>\d+\.\d+)\s+"           # 时间戳
    r"(?P<ch>\d+)\s+"                 # 通道
    r"(?P<id>[0-9A-Fa-f]+x?)\s+"     # CAN ID (可能带 x)
    r"(?P<dir>Rx|Tx)\s+"              # 方向
    r"(?P<type>[dr])\s*"              # d=数据帧 r=远程帧
    r"(?P<dlc>\d+)"                   # DLC
    r"(?P<data>.*)$"                  # 数据字节
)

_ASC_ERROR_RE = re.compile(
    r"^\s*(?P<ts>\d+\.\d+)\s+(?P<ch>\d+)\s+ErrorFrame.*$",
    re.IGNORECASE,
)


def _parse_asc_id(raw: str) -> tuple[int, bool]:
    """解析 .asc 中的 CAN ID 字符串，返回 (id, is_extended)。

    Vector .asc 中扩展帧 ID 通常以 'x' 结尾，标准帧也可能带 'x'。
    我们通过数值范围判断：> 0x7FF 视为扩展帧。
    """
    raw = raw.strip()
    if raw.endswith("x") or raw.endswith("X"):
        raw = raw[:-1]
    can_id = int(raw, 16)
    is_extended = can_id > 0x7FF
    return can_id, is_extended


def parse_asc(filepath: str) -> List[CanFrame]:
    """解析 Vector .asc 格式 CAN 日志文件。

    Args:
        filepath: .asc 文件路径。

    Returns:
        CanFrame 列表，按时间戳排序。
    """
    frames: List[CanFrame] = []

    with open(filepath, "r", encoding="latin-1", errors="replace") as f:
        for line in f:
            line = line.rstrip("\n")

            # 跳过空行和注释
            if not line.strip() or line.strip().startswith("//"):
                continue

            # 错误帧
            m_err = _ASC_ERROR_RE.match(line)
            if m_err:
                frames.append(
                    CanFrame(
                        timestamp=float(m_err.group("ts")),
                        channel=int(m_err.group("ch")),
                        can_id=0,
                        is_extended=False,
                        is_remote=False,
                        is_error=True,
                        direction="Rx",
                        dlc=0,
                        data=[],
                    )
                )
                continue

            # 普通数据/远程帧
            m = _ASC_FRAME_RE.match(line)
            if not m:
                continue

            can_id, is_extended = _parse_asc_id(m.group("id"))
            dlc = int(m.group("dlc"))
            data_str = m.group("data").strip()
            data: List[int] = []
            if data_str and m.group("type") == "d":
                parts = data_str.split()
                data = [int(p, 16) for p in parts[:dlc] if re.match(r"^[0-9A-Fa-f]{2}$", p)]

            frames.append(
                CanFrame(
                    timestamp=float(m.group("ts")),
                    channel=int(m.group("ch")),
                    can_id=can_id,
                    is_extended=is_extended,
                    is_remote=(m.group("type") == "r"),
                    is_error=False,
                    direction=m.group("dir"),
                    dlc=dlc,
                    data=data,
                )
            )

    frames.sort(key=lambda f: f.timestamp)
    return frames


# ---------------------------------------------------------------------------
# Peak .log / candump 简单格式（可选支持）
# ---------------------------------------------------------------------------

# Peak .log 格式示例：
#   1.000 1 100h 8 11 22 33 44 55 66 77 88
# candump 格式：
#   (1234567890.123456) can0 100#1122334455667788

_PEAK_LOG_RE = re.compile(
    r"^\s*(?P<ts>\d+\.\d+)\s+(?P<ch>\d+)\s+"
    r"(?P<id>[0-9A-Fa-f]+)[hH]?\s+(?P<dlc>\d+)\s*(?P<data>.*)$"
)

_CANDUMP_RE = re.compile(
    r"^\s*\((?P<ts>\d+\.\d+)\)\s+\S+\s+"
    r"(?P<id>[0-9A-Fa-f]+)#(?P<data>[0-9A-Fa-f]*)$"
)


def _parse_peak_log(filepath: str) -> List[CanFrame]:
    frames: List[CanFrame] = []
    with open(filepath, "r", encoding="latin-1", errors="replace") as f:
        for line in f:
            m = _PEAK_LOG_RE.match(line.strip())
            if not m:
                continue
            can_id = int(m.group("id"), 16)
            dlc = int(m.group("dlc"))
            data_str = m.group("data").strip()
            data = [int(p, 16) for p in data_str.split()[:dlc]] if data_str else []
            frames.append(
                CanFrame(
                    timestamp=float(m.group("ts")),
                    channel=int(m.group("ch")),
                    can_id=can_id,
                    is_extended=can_id > 0x7FF,
                    is_remote=False,
                    is_error=False,
                    direction="Rx",
                    dlc=dlc,
                    data=data,
                )
            )
    frames.sort(key=lambda f: f.timestamp)
    return frames


def _parse_candump(filepath: str) -> List[CanFrame]:
    frames: List[CanFrame] = []
    with open(filepath, "r", encoding="latin-1", errors="replace") as f:
        for line in f:
            m = _CANDUMP_RE.match(line.strip())
            if not m:
                continue
            can_id = int(m.group("id"), 16)
            data_str = m.group("data")
            data = [int(data_str[i:i+2], 16) for i in range(0, len(data_str), 2)] if data_str else []
            frames.append(
                CanFrame(
                    timestamp=float(m.group("ts")),
                    channel=0,
                    can_id=can_id,
                    is_extended=can_id > 0x7FF,
                    is_remote=False,
                    is_error=False,
                    direction="Rx",
                    dlc=len(data),
                    data=data,
                )
            )
    frames.sort(key=lambda f: f.timestamp)
    return frames


def parse_log_file(filepath: str) -> List[CanFrame]:
    """根据文件扩展名自动选择解析器。

    支持：.asc (Vector), .log (Peak/candump)。
    """
    ext = os.path.splitext(filepath)[1].lower()
    if ext == ".asc":
        return parse_asc(filepath)
    elif ext == ".log":
        # 尝试 Peak 格式，若解析结果为空则尝试 candump
        frames = _parse_peak_log(filepath)
        if frames:
            return frames
        return _parse_candump(filepath)
    else:
        raise ValueError(f"不支持的日志格式: {ext}，目前支持 .asc 和 .log")

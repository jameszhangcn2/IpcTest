"""CAN 日志分析工具包。

支持 Vector .asc 格式日志解析、统计分析与 Excel 汇总导出。
"""

from .parser import CanFrame, parse_asc, parse_log_file
from .analyzer import CanLogAnalyzer, AnalysisResult
from .exporter import export_to_excel

__all__ = [
    "CanFrame",
    "parse_asc",
    "parse_log_file",
    "CanLogAnalyzer",
    "AnalysisResult",
    "export_to_excel",
]

"""Excel 导出器。

将 AnalysisResult 写入多 Sheet 的 Excel 文件：
- 概览 (Overview)
- 报文统计 (Message Statistics)
- 通道统计 (Channel Statistics)
- 错误帧 (Error Frames)
- 原始数据摘要 (Raw Data Summary)
"""

from __future__ import annotations

import os
from typing import Optional

import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill, Border, Side
from openpyxl.utils import get_column_letter

from .analyzer import AnalysisResult


# 样式定义
_HEADER_FONT = Font(bold=True, color="FFFFFF", size=11)
_HEADER_FILL = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
_TITLE_FONT = Font(bold=True, size=14, color="1F4E79")
_SUBTITLE_FONT = Font(bold=True, size=11, color="2E75B6")
_CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)
_LEFT = Alignment(horizontal="left", vertical="center", wrap_text=True)
_THIN_BORDER = Border(
    left=Side(style="thin"),
    right=Side(style="thin"),
    top=Side(style="thin"),
    bottom=Side(style="thin"),
)


def _apply_header_style(ws, row: int, max_col: int):
    """为表头行应用样式。"""
    for col in range(1, max_col + 1):
        cell = ws.cell(row=row, column=col)
        cell.font = _HEADER_FONT
        cell.fill = _HEADER_FILL
        cell.alignment = _CENTER
        cell.border = _THIN_BORDER


def _auto_column_width(ws, max_col: int, min_width: int = 10, max_width: int = 40):
    """自动调整列宽。"""
    for col in range(1, max_col + 1):
        max_len = min_width
        for cell in ws[get_column_letter(col)]:
            if cell.value:
                max_len = max(max_len, min(len(str(cell.value)) + 2, max_width))
        ws.column_dimensions[get_column_letter(col)].width = max_len


def _write_overview_sheet(ws, result: AnalysisResult):
    """写入概览 Sheet。"""
    ws.title = "概览"

    ws.cell(row=1, column=1, value="CAN 日志分析报告").font = _TITLE_FONT
    ws.merge_cells("A1:D1")

    info = [
        ("源文件", os.path.basename(result.file_path) if result.file_path else "N/A"),
        ("总帧数", result.total_frames),
        ("唯一 CAN ID 数", result.unique_ids),
        ("错误帧数", result.total_error_frames),
        ("日志时长 (秒)", f"{result.duration:.3f}"),
        ("通道数", len(result.channels)),
    ]

    row = 3
    ws.cell(row=row, column=1, value="基本信息").font = _SUBTITLE_FONT
    row += 1
    for label, value in info:
        ws.cell(row=row, column=1, value=label).font = Font(bold=True)
        ws.cell(row=row, column=2, value=value)
        ws.cell(row=row, column=1).border = _THIN_BORDER
        ws.cell(row=row, column=2).border = _THIN_BORDER
        row += 1

    # 通道摘要
    row += 1
    ws.cell(row=row, column=1, value="通道摘要").font = _SUBTITLE_FONT
    row += 1
    headers = ["通道", "总帧数", "唯一ID数", "错误帧", "Tx帧数", "Rx帧数", "平均帧率(fps)", "总线负载(%)"]
    for col, h in enumerate(headers, 1):
        ws.cell(row=row, column=col, value=h)
    _apply_header_style(ws, row, len(headers))

    for ch, stats in sorted(result.channels.items()):
        row += 1
        ws.cell(row=row, column=1, value=ch)
        ws.cell(row=row, column=2, value=stats.total_frames)
        ws.cell(row=row, column=3, value=stats.unique_ids)
        ws.cell(row=row, column=4, value=stats.error_frames)
        ws.cell(row=row, column=5, value=stats.tx_frames)
        ws.cell(row=row, column=6, value=stats.rx_frames)
        ws.cell(row=row, column=7, value=round(stats.avg_frames_per_sec, 2))
        ws.cell(row=row, column=8, value=round(stats.bus_load_percent, 2))
        for col in range(1, len(headers) + 1):
            ws.cell(row=row, column=col).border = _THIN_BORDER
            ws.cell(row=row, column=col).alignment = _CENTER

    _auto_column_width(ws, len(headers))


def _write_message_stats_sheet(ws, result: AnalysisResult):
    """写入报文统计 Sheet。"""
    ws.title = "报文统计"

    headers = [
        "通道", "CAN ID (Hex)", "CAN ID (Dec)", "扩展帧", "方向",
        "DLC", "帧数", "首次出现(s)", "最后出现(s)", "持续时间(s)",
        "平均周期(ms)", "最小周期(ms)", "最大周期(ms)", "周期抖动(ms)",
        "平均频率(Hz)", "数据变化次数", "变化率(%)",
    ]

    for col, h in enumerate(headers, 1):
        ws.cell(row=1, column=col, value=h)
    _apply_header_style(ws, 1, len(headers))

    row = 1
    # 按通道、CAN ID 排序
    sorted_msgs = sorted(
        result.messages.items(),
        key=lambda x: (x[0][0], x[0][1]),
    )

    for key, stats in sorted_msgs:
        channel, can_id, direction = key
        if can_id < 0:  # 跳过错误帧分组
            continue
        row += 1

        avg_period_ms = stats.avg_period * 1000 if stats.avg_period else None
        min_period_ms = stats.min_period * 1000 if stats.min_period else None
        max_period_ms = stats.max_period * 1000 if stats.max_period else None
        jitter_ms = stats.period_jitter * 1000 if stats.period_jitter else None
        change_rate = (stats.data_change_count / stats.frame_count * 100) if stats.frame_count > 0 else 0

        values = [
            channel,
            f"0x{can_id:03X}" if not stats.is_extended else f"0x{can_id:08X}",
            can_id,
            "是" if stats.is_extended else "否",
            direction,
            stats.dlc,
            stats.frame_count,
            round(stats.first_time, 6),
            round(stats.last_time, 6),
            round(stats.duration, 6),
            round(avg_period_ms, 3) if avg_period_ms is not None else "N/A",
            round(min_period_ms, 3) if min_period_ms is not None else "N/A",
            round(max_period_ms, 3) if max_period_ms is not None else "N/A",
            round(jitter_ms, 3) if jitter_ms is not None else "N/A",
            round(stats.avg_frequency, 2) if stats.avg_frequency else "N/A",
            stats.data_change_count,
            round(change_rate, 2),
        ]

        for col, v in enumerate(values, 1):
            cell = ws.cell(row=row, column=col, value=v)
            cell.border = _THIN_BORDER
            cell.alignment = _CENTER

    # 冻结首行
    ws.freeze_panes = "A2"
    _auto_column_width(ws, len(headers))


def _write_channel_stats_sheet(ws, result: AnalysisResult):
    """写入通道统计 Sheet。"""
    ws.title = "通道统计"

    headers = [
        "通道", "总帧数", "唯一ID数", "错误帧数", "Tx帧数", "Rx帧数",
        "开始时间(s)", "结束时间(s)", "持续时间(s)", "平均帧率(fps)",
        "估算总线负载(%)",
    ]

    for col, h in enumerate(headers, 1):
        ws.cell(row=1, column=col, value=h)
    _apply_header_style(ws, 1, len(headers))

    row = 1
    for channel, stats in sorted(result.channels.items()):
        row += 1
        values = [
            channel,
            stats.total_frames,
            stats.unique_ids,
            stats.error_frames,
            stats.tx_frames,
            stats.rx_frames,
            round(stats.first_time, 6),
            round(stats.last_time, 6),
            round(stats.duration, 6),
            round(stats.avg_frames_per_sec, 2),
            round(stats.bus_load_percent, 2),
        ]
        for col, v in enumerate(values, 1):
            cell = ws.cell(row=row, column=col, value=v)
            cell.border = _THIN_BORDER
            cell.alignment = _CENTER

    ws.freeze_panes = "A2"
    _auto_column_width(ws, len(headers))


def _write_error_frames_sheet(ws, result: AnalysisResult):
    """写入错误帧 Sheet。"""
    ws.title = "错误帧"

    if not result.error_frames:
        ws.cell(row=1, column=1, value="未检测到错误帧").font = Font(italic=True, color="00B050")
        return

    headers = ["序号", "时间戳(s)", "通道", "方向"]
    for col, h in enumerate(headers, 1):
        ws.cell(row=1, column=col, value=h)
    _apply_header_style(ws, 1, len(headers))

    for i, frame in enumerate(result.error_frames, 1):
        row = i + 1
        values = [i, round(frame.timestamp, 6), frame.channel, frame.direction]
        for col, v in enumerate(values, 1):
            cell = ws.cell(row=row, column=col, value=v)
            cell.border = _THIN_BORDER
            cell.alignment = _CENTER

    ws.freeze_panes = "A2"
    _auto_column_width(ws, len(headers))


def _write_raw_data_summary_sheet(ws, result: AnalysisResult, max_per_id: int = 10):
    """写入原始数据摘要 Sheet（每个 ID 最多采样 max_per_id 帧）。"""
    ws.title = "原始数据摘要"

    headers = ["通道", "时间戳(s)", "CAN ID (Hex)", "方向", "DLC", "数据(Hex)"]
    for col, h in enumerate(headers, 1):
        ws.cell(row=1, column=col, value=h)
    _apply_header_style(ws, 1, len(headers))

    # 重新从 messages 中采样数据
    row = 1
    for key, stats in sorted(result.messages.items(), key=lambda x: (x[0][0], x[0][1])):
        channel, can_id, direction = key
        if can_id < 0:
            continue
        # 从 data_samples 中取最多 max_per_id 个
        samples = stats.data_samples[:max_per_id]
        # 估算时间戳（均匀分布）
        n = len(samples)
        for i, data in enumerate(samples):
            row += 1
            ts = stats.first_time + (stats.duration * i / max(n - 1, 1)) if n > 1 else stats.first_time
            id_hex = f"0x{can_id:03X}" if not stats.is_extended else f"0x{can_id:08X}"
            values = [
                channel,
                round(ts, 6),
                id_hex,
                direction,
                stats.dlc,
                " ".join(f"{b:02X}" for b in data),
            ]
            for col, v in enumerate(values, 1):
                cell = ws.cell(row=row, column=col, value=v)
                cell.border = _THIN_BORDER
                cell.alignment = _LEFT if col == 6 else _CENTER

    ws.freeze_panes = "A2"
    _auto_column_width(ws, len(headers), max_width=60)


def export_to_excel(
    result: AnalysisResult,
    output_path: str,
    include_raw_summary: bool = True,
) -> str:
    """将分析结果导出到 Excel 文件。

    Args:
        result: AnalysisResult 分析结果。
        output_path: 输出 Excel 文件路径。
        include_raw_summary: 是否包含原始数据摘要 Sheet。

    Returns:
        输出文件的绝对路径。
    """
    wb = openpyxl.Workbook()

    # 概览
    ws = wb.active
    _write_overview_sheet(ws, result)

    # 报文统计
    _write_message_stats_sheet(wb.create_sheet(), result)

    # 通道统计
    _write_channel_stats_sheet(wb.create_sheet(), result)

    # 错误帧
    _write_error_frames_sheet(wb.create_sheet(), result)

    # 原始数据摘要
    if include_raw_summary:
        _write_raw_data_summary_sheet(wb.create_sheet(), result)

    # 确保输出目录存在
    output_dir = os.path.dirname(os.path.abspath(output_path))
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    wb.save(output_path)
    return os.path.abspath(output_path)

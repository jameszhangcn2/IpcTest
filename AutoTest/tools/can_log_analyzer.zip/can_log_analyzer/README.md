# CAN 日志分析工具 (pytest + Excel)

基于 pytest 框架的 CAN 日志自动化分析工具，自动解析 CAN 日志、统计分析并汇总到多 Sheet Excel 报告。

## 功能特性

- **多格式支持**：Vector `.asc` (CANoe)、Peak `.log`、candump 格式
- **报文级统计**：每 CAN ID 的帧数、周期（平均/最小/最大/抖动）、频率、数据变化率
- **通道级统计**：总帧数、唯一 ID 数、Tx/Rx 分布、平均帧率、估算总线负载
- **错误帧检测**：自动识别并统计 ErrorFrame
- **扩展帧支持**：自动识别 29 位扩展帧
- **Excel 多 Sheet 导出**：概览、报文统计、通道统计、错误帧、原始数据摘要
- **pytest 集成**：通过命令行参数指定日志文件/目录，支持批量分析、参数化测试、断言校验

## 项目结构

```
can_log_analyzer/
├── can_analyzer/           # 核心包
│   ├── __init__.py
│   ├── parser.py           # CAN 日志解析器（.asc / .log）
│   ├── analyzer.py         # 统计分析器
│   └── exporter.py         # Excel 导出器
├── tests/
│   ├── conftest.py         # pytest 配置与 fixtures
│   └── test_can_analysis.py # 测试用例（参数化 + 单元测试）
├── sample_logs/
│   └── sample.asc          # 示例 CAN 日志
├── output/                 # Excel 输出目录
├── requirements.txt
├── pytest.ini
└── README.md
```

## 安装

```bash
pip install -r requirements.txt
```

## 使用方法

### 1. 分析单个日志文件

```bash
pytest tests/test_can_analysis.py --can-log=path/to/your_log.asc -v
```

生成的 Excel 报告默认在 `output/your_log_analysis.xlsx`。

### 2. 批量分析目录下所有日志

```bash
pytest tests/test_can_analysis.py --can-log-dir=path/to/logs/ --output=reports/ -v
```

### 3. 指定输出路径

```bash
# 输出到目录
pytest --can-log=log.asc --output=./my_reports/

# 输出到具体文件
pytest --can-log=log.asc --output=./result.xlsx
```

### 4. 指定 CAN 波特率（影响总线负载估算）

```bash
pytest --can-log=log.asc --baudrate=250000 -v
```

### 5. 设置最少帧数校验阈值

```bash
pytest --can-log=log.asc --min-frames=100 -v
```

### 6. 使用示例日志（不传参数时默认）

```bash
pytest tests/test_can_analysis.py -v
```

### 7. 仅运行单元测试（不依赖日志文件）

```bash
pytest tests/test_can_analysis.py::TestParserUnit tests/test_can_analysis.py::TestAnalyzerUnit -v
```

## 命令行参数

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `--can-log` | 单个 CAN 日志文件路径 | None |
| `--can-log-dir` | CAN 日志目录（递归搜索 .asc/.log） | None |
| `--output` | Excel 输出目录或文件路径 | `output` |
| `--baudrate` | CAN 总线波特率（bps） | `500000` |
| `--min-frames` | 日志最少帧数校验阈值 | `1` |

## Excel 报告说明

生成的 Excel 包含以下 Sheet：

### 1. 概览
- 源文件名、总帧数、唯一 ID 数、错误帧数、日志时长、通道数
- 各通道摘要（帧数、ID 数、错误帧、Tx/Rx、帧率、总线负载）

### 2. 报文统计
每个 CAN ID 一行，包含：
- 通道、CAN ID（Hex/Dec）、是否扩展帧、方向、DLC
- 帧数、首次/最后出现时间、持续时间
- 平均/最小/最大周期（ms）、周期抖动（ms）
- 平均频率（Hz）
- 数据变化次数、变化率（%）

### 3. 通道统计
每个通道的详细统计：总帧数、唯一 ID 数、错误帧、Tx/Rx 分布、时间范围、平均帧率、估算总线负载。

### 4. 错误帧
所有错误帧的时间戳、通道、方向列表。

### 5. 原始数据摘要
每个 CAN ID 最多采样 10 帧原始数据（Hex），用于快速查看数据内容。

## 作为 Python 库使用

```python
from can_analyzer import parse_log_file, CanLogAnalyzer, export_to_excel

# 解析日志
frames = parse_log_file("path/to/log.asc")

# 分析
analyzer = CanLogAnalyzer(baudrate=500000)
result = analyzer.analyze(frames, file_path="path/to/log.asc")

# 导出 Excel
excel_path = export_to_excel(result, "output/report.xlsx")

# 访问统计数据
for key, stats in result.messages.items():
    channel, can_id, direction = key
    print(f"ID 0x{can_id:03X}: {stats.frame_count} 帧, "
          f"周期 {stats.avg_period*1000:.2f}ms")
```

## 支持的日志格式

### Vector .asc (推荐)
CANoe/CANalyzer 原生格式，文本格式，支持标准帧、扩展帧、远程帧、错误帧。

### Peak .log
PEAK PCAN-View 导出的文本格式。

### candump
Linux `candump` 工具输出格式 `(timestamp) interface id#data`。

## 扩展开发

### 添加 DBC 信号解码
如需基于 DBC 文件解码物理信号，可安装 `cantools` 并在 `analyzer.py` 中扩展：

```python
import cantools
db = cantools.database.load_file("path/to.dbc")
decoded = db.decode_message(frame.can_id, bytes(frame.data))
```

### 添加自定义统计指标
在 `analyzer.py` 的 `MessageStats` / `ChannelStats` 中添加字段，在 `CanLogAnalyzer.analyze()` 中计算，在 `exporter.py` 中添加对应列即可。

## 注意事项

- 总线负载为估算值，基于标准帧约 130 位、扩展帧约 150 位（含位填充）的近似计算
- 大日志文件（>1GB）建议分批处理或使用 `.blf` 二进制格式（需安装 python-can）
- 周期抖动基于标准差计算，仅对帧数 > 2 的报文有效
